// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    site.checkSite();
});