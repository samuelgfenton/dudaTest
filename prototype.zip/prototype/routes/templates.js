const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const { authHeader } = require('../config/settings');

router.get('/', async (req, res) => {
    try {
        const response = await fetch('https://api-sandbox.duda.co/api/sites/multiscreen/templates', {
            headers: authHeader
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const templatesData = await response.json();
        const filteredTemplates = templatesData.filter(template => 
            template.template_name.toLowerCase().includes('siteminder'.toLowerCase())
        );

        res.json(filteredTemplates);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to fetch templates' });
    }
});

module.exports = router;