const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const { authHeader, settings } = require('../config/settings');
const { hexToRgb, delay } = require('../utils/helpers');

router.post('/', async (req, res) => {
    try {
        const { templateId } = req.body;
        
        // 1. Create Site
        const createSiteData = {
            "site_data": {
                "external_uid": settings.spid,
                "site_business_info": {
                    "business_name": settings.propertyName
                }
            },
            "template_id": templateId,
            "default_domain_prefix": settings.channelCode,
            "lang": settings.defaultLanguage
        };

        const response = await fetch('https://api-sandbox.duda.co/api/sites/multiscreen/create', {
            method: 'POST',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(createSiteData)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Wait 500ms before next API call
        await delay(500);

        // 2. Update the theme
        const themeData = {
            "colors": [
                {
                    "id": "color_1",
                    "value": "rgba(247,247,247,1)",
                    "label": "Primary"
                },
                {
                    "id": "color_2",
                    "value": "rgba(70,57,57,1)",
                    "label": "Secondary"
                },
                {
                    "id": "color_3",
                    "value": `rgba(${hexToRgb(settings.colorHex)},1)`,
                    "label": "Color #3"
                },
                {
                    "id": "color_4",
                    "value": "rgba(226, 226, 226, 1)",
                    "label": "Color #4"
                },
                {
                    "id": "color_5",
                    "value": "rgba(0, 0, 0, 0.49)",
                    "label": "Color #5"
                },
                {
                    "id": "color_6",
                    "value": null,
                    "label": null
                },
                {
                    "id": "color_7",
                    "value": null,
                    "label": null
                },
                {
                    "id": "color_8",
                    "value": null,
                    "label": null
                }
            ]
        };

        const themeResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/${data.site_name}/theme`, {
            method: 'PUT',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(themeData)
        });

        if (!themeResponse.ok) {
            throw new Error('Failed to update theme');
        }

        // Wait 500ms before next API call
        await delay(500);

        // 3. Update content
        const contentData = {
            "location_data": {
                "address": {
                    "country": settings.country,
                    "city": settings.city,
                    "region": settings.region,
                    "streetAddress": settings.street,
                    "postalCode": settings.postcode
                },
                "phones": [
                    {
                        "label": "Reception",
                        "phoneNumber": settings.phoneNumber
                    }
                ],
                "emails": [
                    {
                        "emailAddress": settings.emailAddress,
                        "label": "enquiry email address"
                    }
                ]
            },
            "site_texts": {
                "about_us": "",
                "custom": [
                    {
                        "label": "Privacy Policy",
                        "text": ""
                    },
                    {
                        "label": "Terms and Conditions",
                        "text": ""
                    },
                    {
                        "label": "Channel Code",
                        "text": settings.channelCode
                    },
                    {
                        "label": "Domain",
                        "text": settings.domain
                    },
                    {
                        "label": "longitude",
                        "text": settings.longitude
                    },
                    {
                        "label": "latitude",
                        "text": settings.latititude
                    }
                ]
            },
            "site_images": [
                {
                    "label": "HeaderImage",
                    "url": settings.headerImageURL,
                    "alt": "Property Banner"
                }
            ],
            "business_data": {
                "name": settings.propertyName
            }
        };

        const contentResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/${data.site_name}/content`, {
            method: 'POST',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(contentData)
        });

        if (!contentResponse.ok) {
            throw new Error('Failed to update content');
        }

        // Wait 500ms before next API call
        await delay(500);

        // 4. Update room collection
        const roomCollectionData = {
            "external_details": {
                "enabled": true,
                "external_endpoint": `https://samuelgfenton.github.io/dudaTest/${settings.spid}/{lang}/roomsCollection.json`,
                "page_item_url_field": "RoomId",
                "custom_headers": []
            }
        };

        const roomCollectionResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/${data.site_name}/collection/roomCollection`, {
            method: 'PUT',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(roomCollectionData)
        });

        if (!roomCollectionResponse.ok) {
            throw new Error('Failed to update room collection');
        }

        // Wait 500ms before next API call
        await delay(500);

        // 5. Update property collection
        const propertyCollectionData = {
            "external_details": {
                "enabled": true,
                "external_endpoint": `https://samuelgfenton.github.io/dudaTest/${settings.spid}/{lang}/propertyCollection.json`,
                "page_item_url_field": "Item",
                "custom_headers": []
            }
        };

        const propertyCollectionResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/${data.site_name}/collection/propertyCollection`, {
            method: 'PUT',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(propertyCollectionData)
        });

        if (!propertyCollectionResponse.ok) {
            throw new Error('Failed to update property collection');
        }

        // Wait 500ms before next API call
        await delay(500);

        // 6. Update languages
        const additionalLanguages = JSON.parse(settings.additionalLanguages);
        const languagesData = {
            "additionalLanguages": additionalLanguages
        };

        const languagesResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/update/${data.site_name}`, {
            method: 'POST',
            headers: {
                ...authHeader,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(languagesData)
        });

        if (!languagesResponse.ok) {
            throw new Error('Failed to update languages');
        }

        res.json({
            success: true,
            data: data
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to create site' 
        });
    }
});

module.exports = router;