const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const { authHeader, settings } = require('../config/settings');

// Check if account exists
async function checkAccount() {
    const response = await fetch(`https://api-sandbox.duda.co/api/accounts/${settings.userID}`, {
        headers: authHeader
    });
    
    if (response.status === 404) {
        return { exists: false };
    }
    
    if (response.ok) {
        const data = await response.json();
        return { exists: true, data };
    }
    
    throw new Error(`HTTP error! status: ${response.status}`);
}

// Create account
async function createAccount() {
    const accountData = {
        "account_type": "CUSTOMER",
        "account_name": settings.userID,
        "first_name": settings.firstName,
        "last_name": settings.lastName,
        "lang": "en",
        "email": settings.userID,
        "company_name": "company"
    };

    const response = await fetch('https://api-sandbox.duda.co/api/accounts/create', {
        method: 'POST',
        headers: {
            ...authHeader,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(accountData)
    });

    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
}

router.get('/check', async (req, res) => {
    try {
        const accountStatus = await checkAccount();
        res.json(accountStatus);
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to check account' });
    }
});

router.post('/create', async (req, res) => {
    try {
        const accountData = await createAccount();
        res.json({
            success: true,
            data: accountData
        });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ 
            success: false,
            error: 'Failed to create account' 
        });
    }
});

module.exports = router;