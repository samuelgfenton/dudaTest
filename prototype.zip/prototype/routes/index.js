const express = require('express');
const router = express.Router();

const siteRoutes = require('./site');
const templateRoutes = require('./templates');
const createSiteRoutes = require('./createSite');
const accountRoutes = require('./account');

router.use('/account', accountRoutes);
router.use('/site', siteRoutes);
router.use('/templates', templateRoutes);
router.use('/create-site', createSiteRoutes);

module.exports = router;