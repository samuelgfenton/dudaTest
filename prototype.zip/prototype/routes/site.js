const express = require('express');
const router = express.Router();
const fetch = require('node-fetch');
const { authHeader, settings } = require('../config/settings');

router.get('/', async (req, res) => {
    try {
        const response = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/byexternalid/${settings.spid}`, {
            headers: authHeader
        });

        if (response.ok) {
            const siteNames = await response.json();
            
            if (siteNames && siteNames.length > 0) {
                const siteDetailsResponse = await fetch(`https://api-sandbox.duda.co/api/sites/multiscreen/${siteNames[0]}`, {
                    headers: authHeader
                });

                if (siteDetailsResponse.ok) {
                    const siteDetails = await siteDetailsResponse.json();
                    res.json({ 
                        hasSite: true,
                        siteName: siteNames[0],
                        siteDetails: siteDetails
                    });
                } else {
                    throw new Error(`Failed to get site details`);
                }
            } else {
                res.json({ hasSite: false });
            }
        } else {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Failed to fetch site data' });
    }
});

module.exports = router;