const fs = require('fs');

const authHeader = JSON.parse(fs.readFileSync('authHeader.json', 'utf8'));
const rawSettings = JSON.parse(fs.readFileSync('settings.json', 'utf8'));

// Add default values for new fields if they don't exist
const settings = {
    ...rawSettings,
    firstName: rawSettings.firstName || 'Sam',
    lastName: rawSettings.lastName || 'Fenton'
};

module.exports = {
    authHeader,
    settings
};